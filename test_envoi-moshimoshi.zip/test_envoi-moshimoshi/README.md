

- programme d'échange de messages entre un serveur et son client
- commande gcc + fichier a.out pour compiler
- petit message mignon pour embellir la journée 
